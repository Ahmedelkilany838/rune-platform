import { APP_CONFIG } from "@/lib/app-config";
import type { ChatApiResponse, ChatRequest } from "@/lib/chat-types";
import { normalizeWorkflowResponse } from "@/lib/normalize-workflow-response";

type IntakePayload = {
  workspace_id: typeof APP_CONFIG.workspaceId;
  user_id: typeof APP_CONFIG.userId;
  project_id: null;
  conversation_session_id: string | null;
  message_text: string;
  channel: typeof APP_CONFIG.intakeChannel;
  attachments: [];
  metadata: {
    source: typeof APP_CONFIG.metadataSource;
    ui_version: typeof APP_CONFIG.uiVersion;
  };
};

function errorResponse(status: number, errors: string[]) {
  const body: ChatApiResponse = {
    ok: false,
    message_to_user: null,
    conversation_session_id: null,
    prompt_request_id: null,
    generated_output_id: null,
    wf10_status: null,
    output_type: null,
    platform: null,
    generation_layer: null,
    next_workflow: null,
    generated_prompt: null,
    avoid_constraints: null,
    structured_output: null,
    used_knowledge_blocks: null,
    validation_status: null,
    status: null,
    errors,
    raw: {}
  };

  return Response.json(body, { status });
}

function isChatRequest(value: unknown): value is ChatRequest {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;

  const candidate = value as Record<string, unknown>;
  const hasMessage = typeof candidate.message_text === "string";
  const hasSession =
    candidate.conversation_session_id === null ||
    typeof candidate.conversation_session_id === "string" ||
    candidate.conversation_session_id === undefined;

  return hasMessage && hasSession;
}

async function readJson(request: Request) {
  try {
    return (await request.json()) as unknown;
  } catch {
    return null;
  }
}

async function parseResponseJson(response: Response) {
  const text = await response.text();
  if (!text.trim()) return {};

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return {
      errors: ["n8n_response_was_not_valid_json"],
      raw_text_preview: text.slice(0, 500)
    };
  }
}

export async function POST(request: Request) {
  const body = await readJson(request);

  if (!isChatRequest(body)) {
    return errorResponse(400, ["invalid_request_body"]);
  }

  const messageText = body.message_text.trim();

  if (!messageText) {
    return errorResponse(400, ["message_text_required"]);
  }

  if (body.message_text.length > APP_CONFIG.maxMessageCharacters) {
    return errorResponse(400, ["message_text_too_long"]);
  }

  const webhookUrl = process.env.N8N_CHAT_INTAKE_WEBHOOK_URL;

  if (!webhookUrl) {
    return errorResponse(500, ["n8n_chat_intake_webhook_url_missing"]);
  }

  const payload: IntakePayload = {
    workspace_id: APP_CONFIG.workspaceId,
    user_id: APP_CONFIG.userId,
    project_id: APP_CONFIG.projectId,
    conversation_session_id: body.conversation_session_id ?? null,
    message_text: body.message_text,
    channel: APP_CONFIG.intakeChannel,
    attachments: [],
    metadata: {
      source: APP_CONFIG.metadataSource,
      ui_version: APP_CONFIG.uiVersion
    }
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), APP_CONFIG.webhookTimeoutMs);

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    const upstreamJson = await parseResponseJson(response);
    const normalized = normalizeWorkflowResponse(upstreamJson);

    if (!response.ok) {
      return Response.json(
        {
          ...normalized,
          ok: false,
          errors: [
            ...normalized.errors,
            `n8n_request_failed_status_${response.status}`
          ]
        } satisfies ChatApiResponse,
        { status: 502 }
      );
    }

    return Response.json(normalized);
  } catch (error) {
    const isAbort = error instanceof DOMException && error.name === "AbortError";
    return errorResponse(isAbort ? 504 : 502, [isAbort ? "n8n_request_timeout" : "n8n_request_failed"]);
  } finally {
    clearTimeout(timeout);
  }
}
