"use client";

import { Check, Clipboard, Copy } from "lucide-react";
import { useMemo, useState } from "react";
import type { ChatApiResponse } from "@/lib/chat-types";
import { copyToClipboard } from "@/lib/copy";
import { cn, safeJsonStringify } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { TypewriterText } from "@/components/chat/typewriter-text";
import { TechnicalDetails } from "@/components/workspace/technical-details";

type GeneratedPromptCardProps = {
  animate?: boolean;
  response: ChatApiResponse;
};

type CopyKey = "prompt" | "avoid" | "json" | null;
type PromptTab = "prompt" | "avoid" | "structured" | "technical";

const tabs: Array<{ id: PromptTab; label: string }> = [
  { id: "prompt", label: "Prompt" },
  { id: "avoid", label: "Avoid" },
  { id: "structured", label: "Structured" },
  { id: "technical", label: "Technical" }
];

export function GeneratedPromptCard({ animate = false, response }: GeneratedPromptCardProps) {
  const [copied, setCopied] = useState<CopyKey>(null);
  const [activeTab, setActiveTab] = useState<PromptTab>("prompt");
  const fullJson = useMemo(() => safeJsonStringify(response), [response]);
  const structuredJson = useMemo(() => safeJsonStringify(response.structured_output ?? {}), [response.structured_output]);

  if (!response.generated_prompt) return null;

  async function handleCopy(value: string | null, key: CopyKey) {
    const result = await copyToClipboard(value ?? "");
    if (result.ok) {
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1600);
    }
  }

  const copyIcon = (key: CopyKey) =>
    copied === key ? <Check className="h-4 w-4 text-emerald-400" aria-hidden="true" /> : <Copy className="h-4 w-4 text-zinc-400" aria-hidden="true" />;

  return (
    <section className="w-full max-w-[800px] mt-2 mb-6">
      <div className="glass-card rounded-2xl overflow-hidden shadow-2xl relative border border-white/[0.08]">
        {/* Top Header / Toolbar */}
        <div className="border-b border-white/[0.05] bg-dark-surface-elevated/50 px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-brand-500" />
              <p className="text-[11px] uppercase tracking-widest font-semibold text-zinc-500">Creative Engine</p>
            </div>
            <h2 className="text-lg font-display font-medium text-white">Generated Output</h2>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="ghost"
              className="h-8 px-3 text-[13px] bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.05] rounded-lg transition-colors"
              icon={copyIcon("prompt")}
              onClick={() => void handleCopy(response.generated_prompt, "prompt")}
            >
              Copy Prompt
            </Button>
            <Button
              type="button"
              variant="ghost"
              className="h-8 px-3 text-[13px] bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.05] rounded-lg transition-colors"
              icon={copied === "json" ? <Check className="h-4 w-4 text-emerald-400" aria-hidden="true" /> : <Clipboard className="h-4 w-4 text-zinc-400" aria-hidden="true" />}
              onClick={() => void handleCopy(fullJson, "json")}
            >
              Copy JSON
            </Button>
          </div>
        </div>

        {/* Content Area */}
        <div className="px-6 py-5">
          {/* Tags */}
          <div className="mb-6 flex flex-wrap items-center gap-2 text-[11px] font-medium text-brand-300">
            {response.output_type ? <span className="px-2 py-1 bg-brand-500/10 border border-brand-500/20 rounded-md">{response.output_type}</span> : null}
            {response.generation_layer ? <span className="px-2 py-1 bg-brand-500/10 border border-brand-500/20 rounded-md">{response.generation_layer}</span> : null}
            {response.validation_status ? <span className="px-2 py-1 bg-brand-500/10 border border-brand-500/20 rounded-md">{response.validation_status}</span> : null}
          </div>

          {/* Navigation Tabs */}
          <div className="mb-6 border-b border-white/[0.05]">
            <div className="flex gap-6 -mb-px">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  className={cn(
                    "pb-3 text-[13px] font-medium transition-colors border-b-2",
                    activeTab === tab.id ? "border-brand-500 text-brand-100" : "border-transparent text-zinc-500 hover:text-zinc-300 hover:border-zinc-700"
                  )}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Panels */}
          <div className="min-h-[120px]">
            {activeTab === "prompt" ? (
              <article className="animate-fade-in">
                <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed text-zinc-200" dir="auto">
                  <TypewriterText
                    animate={animate}
                    animationKey={`generated:${response.generated_output_id ?? response.prompt_request_id ?? response.generated_prompt.slice(0, 48)}`}
                    text={response.generated_prompt}
                  />
                </p>
              </article>
            ) : null}

            {activeTab === "avoid" ? (
              <article className="animate-fade-in">
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-zinc-100">Avoid Constraints</h3>
                  <Button
                    type="button"
                    variant="ghost"
                    className="h-7 px-2 py-1 text-xs bg-white/[0.05] hover:bg-white/[0.1] rounded-md transition-colors"
                    icon={copyIcon("avoid")}
                    onClick={() => void handleCopy(response.avoid_constraints, "avoid")}
                  >
                    Copy
                  </Button>
                </div>
                <div className="bg-rose-500/5 border border-rose-500/10 rounded-xl p-4">
                  <p className="whitespace-pre-wrap break-words text-[14px] leading-relaxed text-rose-200/80" dir="auto">
                    {response.avoid_constraints || "No avoid constraints returned by the workflow."}
                  </p>
                </div>
              </article>
            ) : null}

            {activeTab === "structured" ? (
              <div className="animate-fade-in relative group">
                <pre className="max-h-[400px] overflow-auto rounded-xl border border-white/[0.05] bg-[#080808] p-5 text-left text-[13px] leading-6 text-zinc-400 font-mono shadow-inner">
                  {structuredJson}
                </pre>
              </div>
            ) : null}

            {activeTab === "technical" ? (
              <div className="animate-fade-in">
                <TechnicalDetails response={response} />
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}

