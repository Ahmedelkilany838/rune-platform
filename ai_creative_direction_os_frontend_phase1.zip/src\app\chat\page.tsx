import { AppShell } from "@/components/app-shell";

export default function ChatPlatform() {
  return <AppShell />;
}
