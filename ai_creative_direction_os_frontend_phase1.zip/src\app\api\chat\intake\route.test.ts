import { afterEach, describe, expect, it, vi } from "vitest";
import { POST } from "@/app/api/chat/intake/route";

function request(body: unknown) {
  return new Request("http://localhost/api/chat/intake", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
}

async function json(response: Response) {
  return (await response.json()) as Record<string, unknown>;
}

describe("POST /api/chat/intake", () => {
  afterEach(() => {
    delete process.env.N8N_CHAT_INTAKE_WEBHOOK_URL;
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it("returns 400 for empty message_text", async () => {
    const response = await POST(request({ message_text: " ", conversation_session_id: null }));
    const body = await json(response);

    expect(response.status).toBe(400);
    expect(body.errors).toEqual(["message_text_required"]);
  });

  it("returns 400 for over-limit message_text", async () => {
    const response = await POST(request({ message_text: "x".repeat(12001), conversation_session_id: null }));
    const body = await json(response);

    expect(response.status).toBe(400);
    expect(body.errors).toEqual(["message_text_too_long"]);
  });

  it("returns 500 without exposing the webhook when env is missing", async () => {
    const response = await POST(request({ message_text: "Create an image prompt", conversation_session_id: null }));
    const body = await json(response);

    expect(response.status).toBe(500);
    expect(body.errors).toEqual(["n8n_chat_intake_webhook_url_missing"]);
    expect(JSON.stringify(body)).not.toContain("https://");
    expect(JSON.stringify(body)).not.toContain("N8N_CHAT_INTAKE_WEBHOOK_URL=");
  });

  it("calls n8n server-side and normalizes the response", async () => {
    process.env.N8N_CHAT_INTAKE_WEBHOOK_URL = "https://n8n.example.test/webhook/wf-00a";

    const fetchMock = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
      expect(String(input)).toBe("https://n8n.example.test/webhook/wf-00a");
      const payload = JSON.parse(String(init?.body)) as Record<string, unknown>;

      expect(payload.workspace_id).toBe("22222222-2222-4222-8222-222222222222");
      expect(payload.user_id).toBe("11111111-1111-4111-8111-111111111111");
      expect(payload.project_id).toBeNull();
      expect(payload.channel).toBe("frontend_chat");
      expect(payload.message_text).toBe("Create a luxury product ad");

      return new Response(
        JSON.stringify({
          message_to_user: "Generated.",
          conversation_session_id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
          wf10_result: {
            wf10_status: "generated",
            prompt_request_id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
            generated_output_id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
            output_type: "product_ad_prompt",
            generation_layer: "layer_1_draft",
            debug: {
              create_generated_output_raw: {
                final_prompt: "A luxury product ad prompt.",
                avoid_constraints: "No generic studio lighting."
              }
            }
          }
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    });

    vi.stubGlobal("fetch", fetchMock);

    const response = await POST(request({ message_text: "Create a luxury product ad", conversation_session_id: null }));
    const body = await json(response);

    expect(response.status).toBe(200);
    expect(body.ok).toBe(true);
    expect(body.generated_prompt).toBe("A luxury product ad prompt.");
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
