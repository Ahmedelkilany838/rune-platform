"use client";

import { Mic, Plus, SendHorizontal } from "lucide-react";
import { useEffect, useRef } from "react";
import { APP_CONFIG } from "@/lib/app-config";
import { cn } from "@/lib/utils";
import { Textarea } from "@/components/ui/textarea";

type ChatComposerProps = {
  disabled: boolean;
  loading?: boolean;
  value: string;
  onChange: (value: string) => void;
  onSubmit: (message: string) => Promise<void>;
  elevated?: boolean;
};

export function ChatComposer({ disabled, loading = false, value, onChange, onSubmit, elevated = false }: ChatComposerProps) {
  const remaining = APP_CONFIG.maxMessageCharacters - value.length;
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const maxHeight = 156;
    textarea.style.height = "0px";
    const nextHeight = Math.min(textarea.scrollHeight, maxHeight);
    textarea.style.height = `${Math.max(32, nextHeight)}px`;
    textarea.style.overflowY = textarea.scrollHeight > maxHeight ? "auto" : "hidden";
  }, [value]);

  async function submit() {
    const nextValue = value.trim();
    if (!nextValue || disabled) return;
    onChange("");
    await onSubmit(nextValue);
  }

  return (
    <form
      className={cn(
        "rounded-[28px] bg-dark-surface border border-white/[0.08] px-4 py-3 shadow-[0_4px_24px_rgba(0,0,0,0.2)] transition-all focus-within:border-brand-500/50 focus-within:bg-dark-surface-elevated",
        elevated && "shadow-[0_18px_70px_rgba(0,0,0,0.4)] border-white/[0.12]"
      )}
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
    >
      <div className="flex min-h-[44px] items-center gap-3">
        <button
          type="button"
          disabled
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/[0.03] border border-white/[0.05] text-zinc-400 transition-all hover:bg-white/[0.1] hover:text-white disabled:opacity-50"
          aria-label="Attach Reference"
          title="Attach Reference"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
        </button>

        <label htmlFor="creative-brief" className="sr-only">
          Creative brief
        </label>
        <Textarea
          ref={textareaRef}
          id="creative-brief"
          rows={1}
          value={value}
          maxLength={APP_CONFIG.maxMessageCharacters}
          disabled={disabled}
          placeholder="What would you like to create?"
          className="no-scrollbar !min-h-8 max-h-[156px] flex-1 rounded-none !border-0 bg-transparent px-1 py-1 text-[15px] leading-6 shadow-none !outline-none !ring-0 focus:!border-transparent focus:!outline-none focus:!ring-0 focus-visible:!outline-none placeholder:text-zinc-600 text-zinc-100"
          onChange={(event) => onChange(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              void submit();
            }
          }}
        />

        <div className="flex shrink-0 items-center gap-2">
          {loading ? <span className="hidden px-2 text-xs font-medium text-brand-400 animate-pulse sm:inline">Generating...</span> : null}
          <button
            type="button"
            disabled
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-400 transition-colors hover:bg-white/[0.08] hover:text-white disabled:opacity-50"
            aria-label="Voice input"
            title="Voice input"
          >
            <Mic className="h-4 w-4" aria-hidden="true" />
          </button>
          <button
            type="submit"
            disabled={disabled || !value.trim()}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-600 text-white transition-all hover:bg-brand-500 hover:shadow-md hover:scale-105 active:scale-95 disabled:bg-white/[0.05] disabled:text-zinc-600 disabled:shadow-none disabled:transform-none disabled:border disabled:border-white/[0.05]"
            aria-label="Send"
            title="Send"
          >
            <SendHorizontal className="h-[18px] w-[18px] -ml-0.5" aria-hidden="true" />
          </button>
        </div>
      </div>
      <p className="sr-only">Supports Arabic, English, mixed briefs, and professional visual prompt requests. {remaining} characters remaining.</p>
    </form>
  );
}
