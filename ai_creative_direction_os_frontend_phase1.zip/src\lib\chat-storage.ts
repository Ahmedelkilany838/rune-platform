import type { ChatApiResponse, ChatMessage } from "@/lib/chat-types";

export const CHAT_HISTORY_STORAGE_KEY = "acd_os_chat_sessions_v1";

export type StoredChatSession = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  conversationSessionId: string | null;
  messages: ChatMessage[];
  latestResponse: ChatApiResponse | null;
  projectId: string | null;
  isPinned?: boolean;
  isArchived?: boolean;
};

export const PROJECT_STORAGE_KEY = "acd_os_projects_v1";

export type StoredProject = {
  id: string;
  name: string;
  instructions: string;
  createdAt: string;
  updatedAt: string;
};

function stripMessageRuntimeState(message: ChatMessage): ChatMessage {
  const { animate: _animate, ...persistentMessage } = message;
  return persistentMessage;
}

function stripSessionRuntimeState(session: StoredChatSession): StoredChatSession {
  return {
    ...session,
    messages: session.messages.map(stripMessageRuntimeState)
  };
}

function isStoredChatSession(value: unknown): value is StoredChatSession {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<StoredChatSession>;
  return (
    typeof candidate.id === "string" &&
    typeof candidate.title === "string" &&
    typeof candidate.createdAt === "string" &&
    typeof candidate.updatedAt === "string" &&
    Array.isArray(candidate.messages)
  );
}

export function loadStoredChatSessions(): StoredChatSession[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(CHAT_HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isStoredChatSession)
      .map(stripSessionRuntimeState)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

export function saveStoredChatSessions(sessions: StoredChatSession[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(CHAT_HISTORY_STORAGE_KEY, JSON.stringify(sessions.map(stripSessionRuntimeState)));
}

export function deleteStoredChatSession(id: string): StoredChatSession[] {
  const current = loadStoredChatSessions();
  const next = current.filter(s => s.id !== id);
  saveStoredChatSessions(next);
  return next;
}

export function renameStoredChatSession(id: string, newTitle: string): StoredChatSession[] {
  const current = loadStoredChatSessions();
  const next = current.map(s => s.id === id ? { ...s, title: newTitle, updatedAt: new Date().toISOString() } : s);
  saveStoredChatSessions(next);
  return next;
}

export function moveStoredChatSession(id: string, newProjectId: string | null): StoredChatSession[] {
  const current = loadStoredChatSessions();
  const next = current.map(s => s.id === id ? { ...s, projectId: newProjectId, updatedAt: new Date().toISOString() } : s);
  saveStoredChatSessions(next);
  return next;
}

export function togglePinStoredChatSession(id: string): StoredChatSession[] {
  const current = loadStoredChatSessions();
  const next = current.map(s => s.id === id ? { ...s, isPinned: !s.isPinned, updatedAt: new Date().toISOString() } : s);
  saveStoredChatSessions(next);
  return next;
}

export function toggleArchiveStoredChatSession(id: string): StoredChatSession[] {
  const current = loadStoredChatSessions();
  const next = current.map(s => s.id === id ? { ...s, isArchived: !s.isArchived, updatedAt: new Date().toISOString() } : s);
  saveStoredChatSessions(next);
  return next;
}

function isStoredProject(value: unknown): value is StoredProject {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<StoredProject>;
  return (
    typeof candidate.id === "string" &&
    typeof candidate.name === "string" &&
    typeof candidate.instructions === "string" &&
    typeof candidate.createdAt === "string" &&
    typeof candidate.updatedAt === "string"
  );
}

export function loadStoredProjects(): StoredProject[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(PROJECT_STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isStoredProject)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  } catch {
    return [];
  }
}

export function saveStoredProjects(projects: StoredProject[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PROJECT_STORAGE_KEY, JSON.stringify(projects));
}

export function createChatTitle(message: string) {
  const trimmed = message.trim().replace(/\s+/g, " ");
  if (!trimmed) return "New chat";
  return trimmed.length > 42 ? `${trimmed.slice(0, 42)}...` : trimmed;
}
