import { AlertTriangle } from "lucide-react";

type ErrorPanelProps = {
  errors: string[];
};

export function ErrorPanel({ errors }: ErrorPanelProps) {
  if (errors.length === 0) return null;

  return (
    <section className="rounded-2xl border border-rose-300/14 bg-rose-300/[0.07] p-3 text-rose-50">
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-4 w-4 text-rose-200/80" aria-hidden="true" />
        <h2 className="text-sm font-semibold">Workflow returned an issue</h2>
      </div>
      <details className="mt-2">
        <summary className="cursor-pointer text-xs text-rose-100/70">View details</summary>
        <ul className="mt-2 space-y-2 text-xs leading-5">
          {errors.map((error) => (
            <li key={error} className="break-words rounded-xl bg-black/20 px-3 py-2 text-rose-100/80">
              {error}
            </li>
          ))}
        </ul>
      </details>
    </section>
  );
}
