"use client";

import { ChatComposer } from "@/components/chat/chat-composer";
import { QuickActionChips } from "@/components/workspace/quick-action-chips";
import { Sparkles } from "lucide-react";

type EmptyHeroProps = {
  disabled: boolean;
  composerValue: string;
  onComposerChange: (value: string) => void;
  onSubmit: (message: string) => Promise<void>;
};

export function EmptyHero({ disabled, composerValue, onComposerChange, onSubmit }: EmptyHeroProps) {
  return (
    <section className="relative mx-auto flex min-h-[calc(100vh-3.5rem)] w-full max-w-[1120px] flex-col items-center justify-center px-4 pb-[10vh] text-center sm:px-8">
      {/* Background Glow */}
      {/* Removed neon background glow */}

      <div className="mb-12 max-w-3xl relative z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-brand-500/30 bg-brand-500/10 text-xs font-medium text-brand-300 mb-6 backdrop-blur-sm animate-fade-in">
          <Sparkles className="w-3.5 h-3.5" />
          Creative Direction Engine
        </div>
        <h2 className="text-balance text-4xl sm:text-5xl md:text-6xl font-display font-bold leading-[1.15] text-white tracking-tight animate-fade-up">
          What are we <span className="text-gradient">creating</span> today?
        </h2>
        <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-zinc-400 animate-fade-up" style={{ animationDelay: "0.1s" }}>
          Turn a rough idea into a comprehensive creative direction, precise visual prompt, or production-ready campaign brief in seconds.
        </p>
      </div>
      <div className="w-full max-w-[860px] relative z-10 animate-fade-up" style={{ animationDelay: "0.2s" }}>
        <ChatComposer disabled={disabled} value={composerValue} onChange={onComposerChange} onSubmit={onSubmit} elevated />
      </div>
      <div className="mt-8 relative z-10 animate-fade-up" style={{ animationDelay: "0.3s" }}>
        <QuickActionChips onSelect={onComposerChange} />
      </div>
    </section>
  );
}
