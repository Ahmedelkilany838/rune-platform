"use client";

import {
  BrainCircuit,
  Folder,
  Image,
  LayoutPanelTop,
  MessageCircle,
  MessageSquarePlus,
  MoreHorizontal,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  Settings,
  Video,
  Wand2,
  Home,
  FolderPlus,
  Plus,
  ChevronRight,
  Trash2,
  Edit2,
  Share,
  UserPlus,
  Pin,
  Archive
} from "lucide-react";
import { useEffect, useState, useRef } from "react";
import { createPortal } from "react-dom";
import type { ComponentType } from "react";
import type { StoredChatSession, StoredProject } from "@/lib/chat-storage";
import { cn } from "@/lib/utils";
import Link from "next/link";

type Shortcut = {
  alt?: boolean;
  ctrl?: boolean;
  key: string;
  shift?: boolean;
  text: string;
};

type SidebarItem = {
  active?: boolean;
  icon: ComponentType<{ className?: string; "aria-hidden"?: boolean }>;
  label: string;
  onSelect: () => void;
  shortcut: Shortcut;
};

type SidebarProps = {
  activeChatId: string | null;
  activeProjectId: string | null;
  chatSessions: StoredChatSession[];
  projects: StoredProject[];
  collapsed: boolean;
  onExpand: () => void;
  onNewPrompt: () => void;
  onSelectChat: (sessionId: string) => void;
  onSetComposerValue: (value: string) => void;
  onToggleCollapsed: () => void;
  onNewProject: () => void;
  onSelectProject: (projectId: string) => void;
  onSelectHome: () => void;
  onDeleteChat: (chatId: string) => void;
  onRenameChat: (chatId: string, newTitle: string) => void;
  onMoveChat: (chatId: string, newProjectId: string | null) => void;
  onTogglePinChat: (chatId: string) => void;
  onToggleArchiveChat: (chatId: string) => void;
};

function isEditableTarget(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  const tagName = target.tagName.toLowerCase();
  return tagName === "input" || tagName === "textarea" || target.isContentEditable;
}

function matchesShortcut(event: KeyboardEvent, shortcut: Shortcut) {
  return (
    event.key.toLowerCase() === shortcut.key.toLowerCase() &&
    event.ctrlKey === Boolean(shortcut.ctrl) &&
    event.shiftKey === Boolean(shortcut.shift) &&
    event.altKey === Boolean(shortcut.alt) &&
    !event.metaKey
  );
}

export function Sidebar({
  activeChatId,
  activeProjectId,
  chatSessions,
  projects,
  collapsed,
  onExpand,
  onNewPrompt,
  onSelectChat,
  onSetComposerValue,
  onToggleCollapsed,
  onNewProject,
  onSelectProject,
  onSelectHome,
  onDeleteChat,
  onRenameChat,
  onMoveChat,
  onTogglePinChat,
  onToggleArchiveChat
}: SidebarProps) {
  const primaryItems: SidebarItem[] = [
    {
      label: "New Chat",
      icon: MessageSquarePlus,
      active: true,
      shortcut: { ctrl: true, shift: true, key: "o", text: "Ctrl + Shift + O" },
      onSelect: onNewPrompt
    },
    {
      label: "Search chats",
      icon: Search,
      shortcut: { ctrl: true, key: "k", text: "Ctrl + K" },
      onSelect: onExpand
    },
    {
      label: "More",
      icon: MoreHorizontal,
      shortcut: { ctrl: true, key: "m", text: "Ctrl + M" },
      onSelect: onExpand
    }
  ];

  const moduleItems: SidebarItem[] = [
    {
      label: "Image Direction",
      icon: Image,
      shortcut: { ctrl: true, alt: true, key: "i", text: "Ctrl + Alt + I" },
      onSelect: () => onSetComposerValue("Create an image prompt for ")
    },
    {
      label: "Video Direction",
      icon: Video,
      shortcut: { ctrl: true, alt: true, key: "v", text: "Ctrl + Alt + V" },
      onSelect: () => onSetComposerValue("Create a video prompt for ")
    },
    {
      label: "Retouching",
      icon: Wand2,
      shortcut: { ctrl: true, alt: true, key: "r", text: "Ctrl + Alt + R" },
      onSelect: () => onSetComposerValue("Create retouching direction for ")
    },
    {
      label: "Campaign Builder",
      icon: LayoutPanelTop,
      shortcut: { ctrl: true, alt: true, key: "c", text: "Ctrl + Alt + C" },
      onSelect: () => onSetComposerValue("Plan a campaign visual direction for ")
    }
  ];

  const homeItem: SidebarItem = {
    label: "Home / All Chats",
    icon: Home,
    active: activeProjectId === null,
    shortcut: { ctrl: true, alt: true, key: "h", text: "Ctrl + Alt + H" },
    onSelect: () => {
      onSelectHome();
      if (collapsed) onExpand();
    }
  };

  const settingsItem: SidebarItem = {
    label: "Settings",
    icon: Settings,
    shortcut: { ctrl: true, key: ",", text: "Ctrl + ," },
    onSelect: onExpand
  };

  // Split chats by active project and exclude archived
  const activeChats = chatSessions.filter(c => !c.isArchived);
  const projectChats = activeProjectId ? activeChats.filter((chat) => chat.projectId === activeProjectId) : [];
  // Home view: show ALL chats; Project view: show only unassigned chats
  const bottomChats = activeProjectId 
    ? activeChats.filter((chat) => chat.projectId === null) 
    : activeChats;

  useEffect(() => {
    const shortcutItems = [...primaryItems, ...moduleItems, homeItem, settingsItem];

    function handleKeyDown(event: KeyboardEvent) {
      if (isEditableTarget(event.target)) return;
      const matchedItem = shortcutItems.find((item) => matchesShortcut(event, item.shortcut));
      if (!matchedItem) return;

      event.preventDefault();
      matchedItem.onSelect();
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [moduleItems, onExpand, onNewPrompt, onSetComposerValue, primaryItems, settingsItem, homeItem]);

  return (
    <aside
      className={cn(
        "fixed inset-y-0 left-0 z-30 hidden h-dvh shrink-0 border-r border-white/[0.05] bg-dark-surface px-3 py-3 transition-[width] duration-300 ease-in-out lg:flex lg:flex-col",
        collapsed ? "w-[64px]" : "w-[252px]"
      )}
      onClick={() => {
        if (collapsed) onExpand();
      }}
    >
      <div
        className={cn(
          "mb-6 flex shrink-0 items-center",
          collapsed ? "h-16 flex-col justify-start gap-2" : "h-10 justify-between gap-3 px-1"
        )}
      >
        <Link href="/" className={cn("flex min-w-0 items-center gap-3", collapsed && "justify-center")}>
          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white shadow-sm">
            <BrainCircuit className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className={cn("min-w-0", collapsed && "sr-only")}>
            <p className="truncate text-[15px] font-semibold leading-tight text-white font-display">ACD OS</p>
            <p className="truncate text-[11px] font-medium leading-tight text-brand-300 mt-0.5">Creative Studio</p>
          </div>
        </Link>
        <button
          type="button"
          data-sidebar-toggle
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-white/[0.08] hover:text-white"
          onClick={(event) => {
            event.stopPropagation();
            onToggleCollapsed();
          }}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <PanelLeftOpen className="h-[18px] w-[18px]" aria-hidden="true" /> : <PanelLeftClose className="h-[18px] w-[18px]" aria-hidden="true" />}
        </button>
      </div>

      <nav className="min-h-0 flex-1 space-y-6 overflow-hidden pr-0.5" aria-label="Workspace navigation">
        <SidebarItemGroup collapsed={collapsed} items={primaryItems} />

        <div>
          <p className={cn("mb-3 px-3 text-[11px] font-semibold tracking-wider uppercase text-zinc-500", collapsed && "sr-only")}>Modules</p>
          <SidebarItemGroup collapsed={collapsed} items={moduleItems} />
        </div>

        <div>
          <SidebarButton collapsed={collapsed} item={homeItem} />
          
          <div className="mt-6 flex items-center justify-between px-3 mb-2">
            <p className={cn("text-[11px] font-semibold tracking-wider uppercase text-zinc-500", collapsed && "sr-only")}>Projects</p>
            {!collapsed && (
              <button
                onClick={onNewProject}
                className="text-zinc-500 hover:text-white transition p-1 rounded-md hover:bg-white/[0.08]"
                title="New Project"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          
          {!collapsed && (
            <div className="space-y-0.5 max-h-[25vh] overflow-y-auto pr-1">
              {projects.map((project) => (
                <button
                  key={project.id}
                  onClick={() => onSelectProject(project.id)}
                  className={cn(
                    "w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-[13px] transition-colors group",
                    activeProjectId === project.id 
                      ? "bg-white/[0.08] text-white" 
                      : "text-zinc-400 hover:bg-white/[0.04] hover:text-zinc-200"
                  )}
                >
                  <Folder className="w-3.5 h-3.5 shrink-0 opacity-70 group-hover:opacity-100" />
                  <span className="truncate">{project.name}</span>
                </button>
              ))}
              {projects.length === 0 && (
                <p className="px-3 py-1 text-xs text-zinc-600">No projects yet.</p>
              )}
            </div>
          )}
        </div>

        {!collapsed && (
          <div className="flex-1 min-h-0 overflow-y-auto flex flex-col pr-1">
            {activeProjectId && (
              <div className="mb-4">
                <ChatSessionList 
                  title="Project Chats"
                  activeChatId={activeChatId} 
                  sessions={projectChats} 
                  projects={projects}
                  onSelectChat={onSelectChat} 
                  onDeleteChat={onDeleteChat}
                  onRenameChat={onRenameChat}
                  onMoveChat={onMoveChat}
                  onNewProject={onNewProject}
                  onTogglePinChat={onTogglePinChat}
                  onToggleArchiveChat={onToggleArchiveChat}
                />
              </div>
            )}
            
            <div className={cn(activeProjectId && "border-t border-white/[0.05] pt-4", "pb-12")}>
              <ChatSessionList 
                title={activeProjectId ? "Unassigned Chats" : "All Chats"}
                activeChatId={activeChatId} 
                sessions={bottomChats} 
                projects={projects}
                onSelectChat={onSelectChat} 
                onDeleteChat={onDeleteChat}
                onRenameChat={onRenameChat}
                onMoveChat={onMoveChat}
                onNewProject={onNewProject}
                onTogglePinChat={onTogglePinChat}
                onToggleArchiveChat={onToggleArchiveChat}
              />
            </div>
          </div>
        )}
      </nav>

      <div className="mt-4 shrink-0">
        <SidebarButton collapsed={collapsed} item={settingsItem} />

        <div className={cn("mt-2 border-t border-white/[0.05] pt-4", collapsed && "flex flex-col items-center")}>
          <button
            type="button"
            className={cn(
              "flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-left transition-colors hover:bg-white/[0.06]",
              collapsed && "h-10 w-10 justify-center p-0"
            )}
            title="DLight Media Solutions - Plus"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-[11px] font-bold text-white shadow-[0_0_0_1px_rgba(255,255,255,0.08)]">
              DL
            </div>
            {!collapsed && (
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium leading-5 text-white">DLight Media</p>
                <p className="text-[11px] leading-4 text-brand-300">Plus Plan</p>
              </div>
            )}
          </button>
        </div>
      </div>
    </aside>
  );
}

function ChatSessionList({
  title,
  activeChatId,
  sessions,
  projects,
  onSelectChat,
  onDeleteChat,
  onRenameChat,
  onMoveChat,
  onNewProject,
  onTogglePinChat,
  onToggleArchiveChat
}: {
  title: string;
  activeChatId: string | null;
  sessions: StoredChatSession[];
  projects: StoredProject[];
  onSelectChat: (sessionId: string) => void;
  onDeleteChat: (chatId: string) => void;
  onRenameChat: (chatId: string, newTitle: string) => void;
  onMoveChat: (chatId: string, newProjectId: string | null) => void;
  onNewProject: () => void;
  onTogglePinChat: (chatId: string) => void;
  onToggleArchiveChat: (chatId: string) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [chatToDelete, setChatToDelete] = useState<string | null>(null);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);
  const [menuPosition, setMenuPosition] = useState<{ top: number; left: number } | null>(null);
  const [showProjectSubmenu, setShowProjectSubmenu] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editingId && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingId]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpenMenuId(null);
        setShowProjectSubmenu(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (sessions.length === 0) {
    return (
      <div className="mt-2">
        <p className="mb-2 px-3 text-[11px] font-semibold tracking-wider uppercase text-zinc-500">{title}</p>
        <p className="px-3 py-2 text-xs text-zinc-600">No chats found.</p>
      </div>
    );
  }

  const handleRenameSubmit = (id: string) => {
    if (editValue.trim()) {
      onRenameChat(id, editValue.trim());
    }
    setEditingId(null);
  };

  const sortedSessions = [...sessions].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return 0;
  });

  return (
    <div className="space-y-0.5">
      <p className="mb-2 px-3 text-[11px] font-semibold tracking-wider uppercase text-zinc-500">{title}</p>
      {sortedSessions.map((session) => (
        <div
          key={session.id}
          className={cn(
            "group flex h-9 w-full items-center justify-between rounded-lg px-3 text-left text-[13px] text-zinc-400 transition-colors hover:bg-white/[0.04] hover:text-zinc-200",
            activeChatId === session.id && "bg-brand-500/10 text-brand-100 font-medium hover:bg-brand-500/15"
          )}
        >
          {editingId === session.id ? (
            <input
              ref={inputRef}
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              onBlur={() => handleRenameSubmit(session.id)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleRenameSubmit(session.id);
                if (e.key === "Escape") setEditingId(null);
              }}
              className="flex-1 bg-transparent border-none outline-none text-white w-full"
            />
          ) : (
            <button
              type="button"
              className="flex-1 truncate text-left pr-2 flex items-center gap-2"
              onClick={() => onSelectChat(session.id)}
              title={session.title}
            >
              {session.isPinned && <Pin className="w-3.5 h-3.5 shrink-0 text-brand-400 rotate-45" />}
              <span className="truncate">{session.title}</span>
            </button>
          )}

          {!editingId && (
            <div className={cn("flex items-center shrink-0", openMenuId === session.id ? "flex" : "hidden group-hover:flex")}>
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (openMenuId === session.id) {
                      setOpenMenuId(null);
                    } else {
                      const rect = e.currentTarget.getBoundingClientRect();
                      // Drop down, but align the *left* edge of the menu with the *right* edge of the button (or just slightly offset)
                      // so it opens outside the sidebar.
                      setMenuPosition({ 
                        top: rect.bottom + 4, 
                        left: rect.left - 4 
                      });
                      setOpenMenuId(session.id);
                    }
                    setShowProjectSubmenu(null);
                  }}
                  className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/[0.08] rounded-md transition-colors"
                  title="More options"
                >
                  <MoreHorizontal className="w-4 h-4" />
                </button>
                
                {openMenuId === session.id && menuPosition && typeof document !== "undefined" && createPortal(
                  <div 
                    ref={menuRef}
                    style={{ top: menuPosition.top, left: menuPosition.left }}
                    className="fixed z-[100] w-60 rounded-xl bg-[#1c1c1c] border border-white/[0.1] shadow-xl py-1 animate-in fade-in zoom-in-95 duration-100"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors">
                      <Share className="w-4 h-4" /> Share
                    </button>
                    <button className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors">
                      <UserPlus className="w-4 h-4" /> Start a group chat
                    </button>
                    <button 
                      onClick={() => {
                        setEditValue(session.title);
                        setEditingId(session.id);
                        setOpenMenuId(null);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors"
                    >
                      <Edit2 className="w-4 h-4" /> Rename
                    </button>
                    
                    <div 
                      className="relative"
                      onMouseEnter={() => setShowProjectSubmenu(session.id)}
                      onMouseLeave={() => setShowProjectSubmenu(null)}
                    >
                      <button className="w-full flex items-center justify-between px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors">
                        <div className="flex items-center gap-3">
                          <FolderPlus className="w-4 h-4" /> Move to project
                        </div>
                        <ChevronRight className="w-4 h-4 opacity-50" />
                      </button>

                      {/* Projects Submenu */}
                      {showProjectSubmenu === session.id && (
                        <div className="absolute left-full top-0 ml-1 w-56 rounded-xl bg-[#262626] border border-white/[0.1] shadow-2xl py-1 animate-in fade-in slide-in-from-left-2 duration-150">
                          <button 
                            onClick={() => {
                              onNewProject();
                              setOpenMenuId(null);
                            }}
                            className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-200 hover:bg-white/[0.08] transition-colors font-medium border-b border-white/[0.05] mb-1"
                          >
                            <Plus className="w-4 h-4" /> New project
                          </button>
                          
                          <div className="max-h-60 overflow-y-auto">
                            {projects.map(proj => (
                              <button 
                                key={proj.id}
                                onClick={() => {
                                  onMoveChat(session.id, proj.id);
                                  setOpenMenuId(null);
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-white/[0.08] transition-colors"
                              >
                                <Folder className="w-4 h-4 shrink-0 opacity-70" />
                                <span className="truncate">{proj.name}</span>
                              </button>
                            ))}
                            {projects.length === 0 && (
                              <p className="px-3 py-2 text-xs text-zinc-500">No projects yet.</p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    <button 
                      onClick={() => {
                        onTogglePinChat(session.id);
                        setOpenMenuId(null);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors border-t border-white/[0.05] mt-1 pt-2"
                    >
                      <Pin className={cn("w-4 h-4", session.isPinned && "fill-current")} /> {session.isPinned ? "Unpin chat" : "Pin chat"}
                    </button>
                    <button 
                      onClick={() => {
                        onToggleArchiveChat(session.id);
                        setOpenMenuId(null);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-zinc-300 hover:bg-brand-500/10 hover:text-white transition-colors"
                    >
                      <Archive className="w-4 h-4" /> {session.isArchived ? "Unarchive" : "Archive"}
                    </button>
                    <button 
                      onClick={() => {
                        setChatToDelete(session.id);
                        setOpenMenuId(null);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-[13px] text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" /> Delete
                    </button>
                  </div>,
                  document.body
                )}
              </div>
            </div>
          )}
        </div>
      ))}

      {/* Custom Delete Confirmation Modal */}
      {chatToDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setChatToDelete(null)}>
          <div 
            className="w-full max-w-sm rounded-2xl border border-white/[0.08] bg-dark-surface shadow-2xl p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-display font-semibold text-white mb-2">Delete Chat</h3>
            <p className="text-sm text-zinc-400 mb-6">Are you sure you want to delete this chat? This action cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setChatToDelete(null)}
                className="px-4 py-2 text-sm font-medium text-zinc-300 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteChat(chatToDelete);
                  setChatToDelete(null);
                }}
                className="px-4 py-2 text-sm font-medium bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 rounded-xl transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SidebarItemGroup({ collapsed, items }: { collapsed: boolean; items: SidebarItem[] }) {
  return (
    <div className="space-y-0.5">
      {items.map((item) => (
        <SidebarButton key={item.label} collapsed={collapsed} item={item} />
      ))}
    </div>
  );
}

function SidebarButton({ collapsed, item }: { collapsed: boolean; item: SidebarItem }) {
  const Icon = item.icon;

  return (
    <div className="group relative">
      <button
        type="button"
        onClick={item.onSelect}
        className={cn(
          "flex h-9 w-full items-center gap-3 rounded-lg px-3 text-left text-[13px] font-medium text-zinc-300 transition-colors hover:bg-white/[0.06] hover:text-white",
          collapsed && "justify-center px-0",
          item.active && "bg-brand-600 text-white shadow-sm hover:bg-brand-500"
        )}
        aria-label={collapsed ? `${item.label}, ${item.shortcut.text}` : undefined}
      >
        <Icon className={cn("h-[18px] w-[18px] shrink-0", item.active ? "text-white" : "text-zinc-400 group-hover:text-zinc-200")} aria-hidden={true} />
        <span className={cn("min-w-0 flex-1 truncate", collapsed && "sr-only")}>{item.label}</span>
      </button>

      {collapsed && (
        <div className="pointer-events-none absolute left-[56px] top-1/2 z-50 hidden -translate-y-1/2 items-center gap-2 rounded-lg border border-white/[0.08] bg-dark-surface-elevated px-3 py-2 text-[13px] font-medium text-white shadow-xl group-hover:flex backdrop-blur-md">
          <span className="whitespace-nowrap">{item.label}</span>
          <kbd className="whitespace-nowrap text-[10px] font-bold tracking-wider text-zinc-500">{item.shortcut.text}</kbd>
        </div>
      )}
    </div>
  );
}
