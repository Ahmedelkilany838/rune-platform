import type { ChatMessage } from "@/lib/chat-types";
import { cn } from "@/lib/utils";
import { TypewriterText } from "@/components/chat/typewriter-text";
import { Sparkles } from "lucide-react";

type MessageBubbleProps = {
  message: ChatMessage;
  compact?: boolean;
};

export function MessageBubble({ message, compact = false }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const isError = message.role === "error";

  return (
    <article className={cn("flex items-end gap-3", isUser ? "justify-end" : "justify-start")}>
      {!isUser && <AssistantMark tone={isError ? "error" : "normal"} />}
      <div
        className={cn(
          "max-w-[85%] sm:max-w-[76%] rounded-[20px] px-5 py-4 text-[15px] leading-relaxed shadow-lg",
          compact && "px-4 py-3 text-sm leading-6",
          isUser && "rounded-tr-sm bg-brand-600 text-white shadow-md border border-brand-500/50",
          !isUser && !isError && "rounded-bl-sm bg-dark-surface-elevated text-zinc-100 border border-white/[0.08] shadow-[0_4px_24px_rgba(0,0,0,0.2)] backdrop-blur-md",
          isError && "rounded-bl-sm border border-rose-500/30 bg-rose-500/10 text-rose-200"
        )}
        dir="auto"
      >
        <p className="whitespace-pre-wrap break-words">
          {!isUser && !isError ? (
            <TypewriterText animate={message.animate} animationKey={`message:${message.id}`} text={message.content} />
          ) : (
            message.content
          )}
        </p>
      </div>
    </article>
  );
}

export function AssistantMark({ tone = "normal" }: { tone?: "normal" | "error" }) {
  return (
    <div
      className={cn(
        "flex h-8 w-8 shrink-0 items-center justify-center rounded-xl",
        tone === "error" ? "bg-rose-500/20 text-rose-300" : "bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-md"
      )}
      aria-hidden="true"
    >
      {tone === "error" ? <span className="font-bold text-[12px]">!</span> : <Sparkles className="h-4 w-4" />}
    </div>
  );
}
