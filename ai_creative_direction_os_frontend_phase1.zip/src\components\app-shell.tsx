"use client";

import { useEffect, useRef, useState } from "react";
import type { ChatApiResponse, ChatMessage, ConnectionStatus } from "@/lib/chat-types";
import { createChatTitle, loadStoredChatSessions, saveStoredChatSessions, loadStoredProjects, saveStoredProjects, deleteStoredChatSession, renameStoredChatSession, moveStoredChatSession, togglePinStoredChatSession, toggleArchiveStoredChatSession, type StoredChatSession, type StoredProject } from "@/lib/chat-storage";
import { cn, createClientId } from "@/lib/utils";
import { ChatPanel } from "@/components/chat/chat-panel";
import { Sidebar } from "@/components/workspace/sidebar";
import { Topbar } from "@/components/workspace/topbar";
import { NewProjectModal } from "@/components/workspace/new-project-modal";
import { ProjectDashboard } from "@/components/workspace/project-dashboard";

export function AppShell() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadingChatIds, setLoadingChatIds] = useState<string[]>([]);
  const [latestResponse, setLatestResponse] = useState<ChatApiResponse | null>(null);
  const [conversationSessionId, setConversationSessionId] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("not_tested");
  const [composerValue, setComposerValue] = useState("");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatSessions, setChatSessions] = useState<StoredChatSession[]>([]);
  const [projects, setProjects] = useState<StoredProject[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [showProjectDashboard, setShowProjectDashboard] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const activeChatIdRef = useRef<string | null>(null);
  const chatSessionsRef = useRef<StoredChatSession[]>([]);

  useEffect(() => {
    activeChatIdRef.current = activeChatId;
  }, [activeChatId]);

  useEffect(() => {
    chatSessionsRef.current = chatSessions;
  }, [chatSessions]);

  useEffect(() => {
    setChatSessions(loadStoredChatSessions());
    setProjects(loadStoredProjects());
  }, []);

  function persistSessions(nextSessions: StoredChatSession[]) {
    const sortedSessions = [...nextSessions].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    chatSessionsRef.current = sortedSessions;
    setChatSessions(sortedSessions);
    saveStoredChatSessions(sortedSessions);
  }

  function startNewChat() {
    const now = new Date().toISOString();
    const newSession: StoredChatSession = {
      id: createClientId("chat"),
      title: "New chat",
      createdAt: now,
      updatedAt: now,
      conversationSessionId: null,
      messages: [],
      latestResponse: null,
      projectId: activeProjectId
    };

    const currentSessions = chatSessionsRef.current;
    persistSessions([newSession, ...currentSessions]);
    setActiveChatId(newSession.id);
    setMessages([]);
    setConversationSessionId(null);
    setLatestResponse(null);
    setConnectionStatus("not_tested");
    setShowProjectDashboard(false);
    setComposerValue("");
  }

  function handleCreateProject(name: string, instructions: string) {
    const now = new Date().toISOString();
    const newProject: StoredProject = {
      id: createClientId("proj"),
      name,
      instructions,
      createdAt: now,
      updatedAt: now
    };
    const nextProjects = [newProject, ...projects];
    setProjects(nextProjects);
    saveStoredProjects(nextProjects);
    setActiveProjectId(newProject.id);
    setIsProjectModalOpen(false);
    setShowProjectDashboard(true);
    setActiveChatId(null);
  }

  function updateSession(session: StoredChatSession) {
    const currentSessions = chatSessionsRef.current;
    const withoutCurrent = currentSessions.filter(
      (item) => item.id !== session.id && item.conversationSessionId !== session.conversationSessionId
    );
    persistSessions([session, ...withoutCurrent]);
  }

  function selectChatSession(sessionId: string) {
    const session = chatSessionsRef.current.find((s) => s.id === sessionId);
    if (!session) return;
    
    setActiveChatId(sessionId);
    if (session.projectId) {
      setActiveProjectId(session.projectId);
    }
    setShowProjectDashboard(false);
    setMessages(session.messages);
    setConversationSessionId(session.conversationSessionId);
    setLatestResponse(session.latestResponse);
    setConnectionStatus(session.latestResponse ? (session.latestResponse.ok ? "connected" : "error") : "not_tested");
    setComposerValue("");
  }

  function handleDeleteChat(chatId: string) {
    const next = deleteStoredChatSession(chatId);
    chatSessionsRef.current = next;
    setChatSessions(next);
    if (activeChatId === chatId) {
      // If we're in a project, go back to project dashboard; otherwise clear state
      if (activeProjectId) {
        setActiveChatId(null);
        setMessages([]);
        setConversationSessionId(null);
        setLatestResponse(null);
        setShowProjectDashboard(true);
      } else {
        setActiveChatId(null);
        setMessages([]);
        setConversationSessionId(null);
        setLatestResponse(null);
      }
    }
  }

  function handleRenameChat(chatId: string, newTitle: string) {
    const next = renameStoredChatSession(chatId, newTitle);
    chatSessionsRef.current = next;
    setChatSessions(next);
  }

  function handleMoveChat(chatId: string, newProjectId: string | null) {
    const next = moveStoredChatSession(chatId, newProjectId);
    chatSessionsRef.current = next;
    setChatSessions(next);
  }

  function handleTogglePinChat(chatId: string) {
    const next = togglePinStoredChatSession(chatId);
    chatSessionsRef.current = next;
    setChatSessions(next);
  }

  function handleToggleArchiveChat(chatId: string) {
    const next = toggleArchiveStoredChatSession(chatId);
    chatSessionsRef.current = next;
    setChatSessions(next);
    // If we just archived the active chat, clear chat view
    if (activeChatId === chatId) {
      setActiveChatId(null);
      setMessages([]);
      setConversationSessionId(null);
      setLatestResponse(null);
      if (activeProjectId) {
        setShowProjectDashboard(true);
      }
    }
  }

  function upsertChatSession({
    chatId,
    nextConversationSessionId,
    nextLatestResponse,
    nextMessages,
    titleSource
  }: {
    chatId: string;
    nextConversationSessionId: string | null;
    nextLatestResponse: ChatApiResponse | null;
    nextMessages: ChatMessage[];
    titleSource?: string;
  }) {
    const now = new Date().toISOString();
    const id = chatId;
    const currentSessions = chatSessionsRef.current;
    const existingSession = currentSessions.find((session) => session.id === chatId || session.conversationSessionId === nextConversationSessionId);
    const title = existingSession?.title && existingSession.title !== "New chat" ? existingSession.title : createChatTitle(titleSource ?? "");
    const nextSession: StoredChatSession = {
      id,
      title,
      createdAt: existingSession?.createdAt ?? now,
      updatedAt: now,
      conversationSessionId: nextConversationSessionId,
      messages: nextMessages,
      latestResponse: nextLatestResponse,
      projectId: existingSession?.projectId ?? activeProjectId,
      isPinned: existingSession?.isPinned,
      isArchived: existingSession?.isArchived
    };
    updateSession(nextSession);
  }

  async function submitMessage(message: string) {
    const trimmed = message.trim();
    if (!trimmed) return;
    const now = new Date().toISOString();
    const requestChatId = activeChatId ?? createClientId("chat");
    const requestConversationSessionId = conversationSessionId;
    const baseSession =
      chatSessionsRef.current.find((session) => session.id === requestChatId) ??
      ({
        id: requestChatId,
        title: createChatTitle(trimmed),
        createdAt: now,
        updatedAt: now,
        conversationSessionId: requestConversationSessionId,
        messages: [],
        latestResponse: null,
        projectId: activeProjectId
      } satisfies StoredChatSession);

    const userMessage: ChatMessage = {
      id: createClientId("user"),
      role: "user",
      content: trimmed,
      createdAt: new Date().toISOString()
    };

    const messagesWithUser = [...baseSession.messages, userMessage];
    if (!activeChatId) {
      setActiveChatId(requestChatId);
    }
    setMessages(messagesWithUser);
    upsertChatSession({
      chatId: requestChatId,
      nextConversationSessionId: requestConversationSessionId,
      nextLatestResponse: baseSession.latestResponse,
      nextMessages: messagesWithUser,
      titleSource: trimmed
    });
    setLoadingChatIds((current) => (current.includes(requestChatId) ? current : [...current, requestChatId]));

    try {
      const response = await fetch("/api/chat/intake", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message_text: trimmed,
          conversation_session_id: requestConversationSessionId
        })
      });

      const data = (await response.json()) as ChatApiResponse;
      const nextConversationSessionId = data.conversation_session_id ?? requestConversationSessionId;
      const nextConnectionStatus = response.ok && data.ok && data.errors.length === 0 ? "connected" : "error";
      const latestRequestSession = chatSessionsRef.current.find((session) => session.id === requestChatId) ?? baseSession;

      if (data.message_to_user) {
        const messagesWithAssistant: ChatMessage[] = [
          ...latestRequestSession.messages,
          {
            id: createClientId("assistant"),
            animate: activeChatIdRef.current === requestChatId,
            role: "assistant",
            content: data.message_to_user ?? "",
            createdAt: new Date().toISOString(),
            response: data
          }
        ];
        if (activeChatIdRef.current === requestChatId) {
          setMessages(messagesWithAssistant);
          setLatestResponse(data);
          setConversationSessionId(nextConversationSessionId);
          setConnectionStatus(nextConnectionStatus);
        }
        upsertChatSession({
          chatId: requestChatId,
          nextConversationSessionId,
          nextLatestResponse: data,
          nextMessages: messagesWithAssistant,
          titleSource: trimmed
        });
      } else if (data.errors.length > 0) {
        const messagesWithError: ChatMessage[] = [
          ...latestRequestSession.messages,
          {
            id: createClientId("error"),
            role: "error",
            content: "The workflow returned an issue. Details are available in the response panel.",
            createdAt: new Date().toISOString(),
            response: data
          }
        ];
        if (activeChatIdRef.current === requestChatId) {
          setMessages(messagesWithError);
          setLatestResponse(data);
          setConversationSessionId(nextConversationSessionId);
          setConnectionStatus(nextConnectionStatus);
        }
        upsertChatSession({
          chatId: requestChatId,
          nextConversationSessionId,
          nextLatestResponse: data,
          nextMessages: messagesWithError,
          titleSource: trimmed
        });
      } else {
        if (activeChatIdRef.current === requestChatId) {
          setLatestResponse(data);
          setConversationSessionId(nextConversationSessionId);
          setConnectionStatus(nextConnectionStatus);
        }
        upsertChatSession({
          chatId: requestChatId,
          nextConversationSessionId,
          nextLatestResponse: data,
          nextMessages: latestRequestSession.messages,
          titleSource: trimmed
        });
      }
    } catch {
      const failedResponse: ChatApiResponse = {
        ok: false,
        message_to_user: null,
        conversation_session_id: requestConversationSessionId,
        prompt_request_id: null,
        generated_output_id: null,
        wf10_status: null,
        output_type: null,
        platform: null,
        generation_layer: null,
        next_workflow: null,
        generated_prompt: null,
        avoid_constraints: null,
        structured_output: null,
        used_knowledge_blocks: null,
        validation_status: null,
        status: null,
        errors: ["frontend_request_failed"],
        raw: {}
      };

      const failedMessages: ChatMessage[] = [
        ...(chatSessionsRef.current.find((session) => session.id === requestChatId)?.messages ?? messagesWithUser),
        {
          id: createClientId("error"),
          role: "error",
          content: "The frontend could not reach the intake API route.",
          createdAt: new Date().toISOString(),
          response: failedResponse
        }
      ];
      if (activeChatIdRef.current === requestChatId) {
        setMessages(failedMessages);
        setLatestResponse(failedResponse);
        setConnectionStatus("error");
      }
      upsertChatSession({
        chatId: requestChatId,
        nextConversationSessionId: requestConversationSessionId,
        nextLatestResponse: failedResponse,
        nextMessages: failedMessages,
        titleSource: trimmed
      });
    } finally {
      setLoadingChatIds((current) => current.filter((chatId) => chatId !== requestChatId));
    }
  }

  // Determine what view to show
  const activeProject = activeProjectId ? projects.find(p => p.id === activeProjectId) : null;
  const shouldShowDashboard = showProjectDashboard && activeProject && !activeChatId;

  return (
    <div className="min-h-screen overflow-hidden bg-black text-zinc-100">
      <div className="pointer-events-none fixed inset-0 bg-black" />
      <div className="relative flex min-h-screen">
        <Sidebar
          activeChatId={activeChatId}
          activeProjectId={activeProjectId}
          chatSessions={chatSessions}
          projects={projects}
          collapsed={sidebarCollapsed}
          onExpand={() => setSidebarCollapsed(false)}
          onNewPrompt={startNewChat}
          onSelectChat={selectChatSession}
          onSetComposerValue={setComposerValue}
          onToggleCollapsed={() => setSidebarCollapsed((current) => !current)}
          onNewProject={() => setIsProjectModalOpen(true)}
          onSelectProject={(id) => {
            setActiveProjectId(id);
            setActiveChatId(null);
            setMessages([]);
            setConversationSessionId(null);
            setLatestResponse(null);
            setShowProjectDashboard(true);
          }}
          onSelectHome={() => {
            setActiveProjectId(null);
            setActiveChatId(null);
            setMessages([]);
            setConversationSessionId(null);
            setLatestResponse(null);
            setShowProjectDashboard(false);
          }}
          onDeleteChat={handleDeleteChat}
          onRenameChat={handleRenameChat}
          onMoveChat={handleMoveChat}
          onTogglePinChat={handleTogglePinChat}
          onToggleArchiveChat={handleToggleArchiveChat}
        />

        <main
          className={cn(
            "flex h-dvh min-w-0 flex-1 flex-col transition-[padding-left] duration-200 ease-out lg:pl-[252px]",
            sidebarCollapsed && "lg:pl-[64px]"
          )}
        >
          <Topbar connectionStatus={connectionStatus} onNewPrompt={startNewChat} activeProjectName={activeProject?.name} />
          
          {shouldShowDashboard ? (
            <ProjectDashboard 
              project={activeProject!}
              chats={chatSessions.filter(c => c.projectId === activeProjectId && !c.isArchived)}
              onSelectChat={selectChatSession}
              onNewChat={startNewChat}
            />
          ) : (
            <ChatPanel
              messages={messages}
              latestResponse={latestResponse}
              loading={activeChatId ? loadingChatIds.includes(activeChatId) : false}
              composerValue={composerValue}
              onComposerChange={setComposerValue}
              onSubmit={submitMessage}
            />
          )}
        </main>
      </div>

      <NewProjectModal
        isOpen={isProjectModalOpen}
        onClose={() => setIsProjectModalOpen(false)}
        onSubmit={handleCreateProject}
      />
    </div>
  );
}
