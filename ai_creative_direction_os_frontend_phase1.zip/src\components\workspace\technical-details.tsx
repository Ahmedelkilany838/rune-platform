"use client";

import type { ChatApiResponse } from "@/lib/chat-types";
import { formatId, safeJsonStringify } from "@/lib/utils";

type TechnicalDetailsProps = {
  response: ChatApiResponse;
};

export function TechnicalDetails({ response }: TechnicalDetailsProps) {
  const usedKnowledgeCount = response.used_knowledge_blocks?.length ?? 0;

  return (
    <div className="space-y-4">
      <dl className="grid gap-3 sm:grid-cols-2">
        <TechnicalRow label="Prompt Request ID" value={formatId(response.prompt_request_id)} title={response.prompt_request_id ?? undefined} />
        <TechnicalRow label="Generated Output ID" value={formatId(response.generated_output_id)} title={response.generated_output_id ?? undefined} />
        <TechnicalRow label="Conversation Session ID" value={formatId(response.conversation_session_id)} title={response.conversation_session_id ?? undefined} />
        <TechnicalRow label="Backend Status" value={response.status ?? response.wf10_status ?? "None"} />
        <TechnicalRow label="Next Workflow" value={response.next_workflow ?? "None"} />
        <TechnicalRow label="Used Knowledge Count" value={String(usedKnowledgeCount)} />
      </dl>

      <details className="rounded-2xl border border-white/[0.07] bg-black/18">
        <summary className="cursor-pointer px-4 py-3 text-sm font-medium text-zinc-300">Raw response JSON</summary>
        <pre className="max-h-[380px] overflow-auto border-t border-white/[0.07] p-4 text-left text-xs leading-5 text-zinc-500">
          {safeJsonStringify(response.raw)}
        </pre>
      </details>
    </div>
  );
}

function TechnicalRow({ label, value, title }: { label: string; value: string; title?: string }) {
  return (
    <div className="rounded-2xl bg-white/[0.035] px-4 py-3">
      <dt className="mb-1 text-[10px] font-medium uppercase tracking-[0.18em] text-zinc-600">{label}</dt>
      <dd className="break-words font-mono text-xs text-zinc-300" title={title}>
        {value}
      </dd>
    </div>
  );
}
