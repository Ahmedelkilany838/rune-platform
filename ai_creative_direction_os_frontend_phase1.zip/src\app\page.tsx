import Link from "next/link";
import { ArrowRight, Sparkles, Zap, Layers, Cpu, Image as ImageIcon, Video, Wand2, LayoutPanelTop, CheckCircle2, ChevronRight, Play } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#030303] text-zinc-100 selection:bg-brand-500/30 font-sans overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#030303]/70 backdrop-blur-2xl border-b border-white/[0.04] transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-brand-700 to-brand-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-display font-semibold text-lg tracking-tight text-white/90">ACD OS</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
            <a href="#features" className="hover:text-white transition-colors duration-300">Features</a>
            <a href="#workflow" className="hover:text-white transition-colors duration-300">How it Works</a>
            <a href="#demo" className="hover:text-white transition-colors duration-300">Use Cases</a>
          </div>
          <Link
            href="/chat"
            className="group relative h-9 px-5 rounded-full bg-white text-black flex items-center gap-2 text-sm font-medium hover:bg-zinc-100 transition-all duration-300 shadow-[0_0_0_1px_rgba(255,255,255,1)] hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              Go to Workspace
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform duration-300" />
            </span>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6">
        {/* Subtle Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        
        <div className="relative max-w-5xl mx-auto text-center animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.08] bg-white/[0.02] text-xs font-medium text-brand-300 mb-10 backdrop-blur-sm shadow-sm hover:bg-white/[0.04] transition-colors duration-300 cursor-default">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
            </span>
            ACD OS 2.0 is now available
          </div>
          
          <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-display font-bold tracking-tight mb-8 leading-[1.05] text-white">
            The intelligent <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-zinc-100 via-brand-200 to-zinc-400">Creative Direction</span> system.
          </h1>
          
          <p className="text-lg md:text-xl text-zinc-400 mb-12 max-w-2xl mx-auto leading-relaxed font-light tracking-wide">
            Elevate your creative process with AI-driven visual direction, precise prompt engineering, and intelligent campaign building. Professional grade. Zero compromises.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
            <Link
              href="/chat"
              className="group relative h-14 px-8 rounded-full bg-brand-600 text-white flex items-center gap-2 text-base font-medium transition-all duration-500 hover:bg-brand-500 hover:scale-[1.02] active:scale-[0.98] shadow-[0_8px_20px_rgba(37,73,235,0.2)] hover:shadow-[0_12px_25px_rgba(37,73,235,0.3)]"
            >
              Start Creating 
              <Sparkles className="w-4 h-4 ml-1 group-hover:rotate-12 transition-transform duration-300" />
            </Link>
            <a
              href="#demo"
              className="group h-14 px-8 rounded-full bg-white/[0.03] border border-white/[0.08] text-zinc-200 flex items-center gap-2 text-base font-medium hover:bg-white/[0.08] transition-all duration-500 hover:scale-[1.02] active:scale-[0.98]"
            >
              Watch Demo 
              <div className="w-6 h-6 rounded-full bg-white/[0.1] flex items-center justify-center ml-1 group-hover:bg-white text-white group-hover:text-black transition-colors duration-300">
                <Play className="w-3 h-3 fill-current" />
              </div>
            </a>
          </div>
        </div>

        {/* Dashboard Preview Mockup */}
        <div className="relative mt-24 max-w-6xl mx-auto animate-fade-up" style={{ animationDelay: "0.2s" }}>
          <div className="rounded-3xl border border-white/[0.08] bg-[#0A0A0A]/80 backdrop-blur-3xl p-3 shadow-2xl overflow-hidden ring-1 ring-white/[0.02]">
            <div className="rounded-2xl overflow-hidden bg-black border border-white/[0.04] aspect-[16/9] md:aspect-[21/9] relative flex items-center justify-center group">
               <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:32px_32px]"></div>
               
               {/* Abstract floating elements simulating UI */}
               <div className="absolute top-8 left-8 w-48 h-12 bg-white/[0.03] rounded-xl border border-white/[0.05] flex items-center px-4 gap-3 transform group-hover:translate-x-2 transition-transform duration-700">
                  <div className="w-4 h-4 rounded-full bg-brand-500/50"></div>
                  <div className="w-24 h-2 bg-white/[0.1] rounded-full"></div>
               </div>
               <div className="absolute bottom-8 right-8 w-64 h-32 bg-white/[0.03] rounded-2xl border border-white/[0.05] p-5 transform group-hover:-translate-y-2 transition-transform duration-700">
                  <div className="w-full h-3 bg-white/[0.1] rounded-full mb-3"></div>
                  <div className="w-3/4 h-3 bg-white/[0.05] rounded-full mb-6"></div>
                  <div className="w-full h-8 bg-brand-500/10 rounded-lg border border-brand-500/20"></div>
               </div>

               <div className="flex flex-col items-center gap-5 relative z-10">
                 <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-white/[0.08] to-white/[0.01] border border-white/[0.1] flex items-center justify-center text-brand-400 shadow-2xl backdrop-blur-xl group-hover:scale-110 transition-transform duration-700 ease-out">
                    <Cpu className="w-10 h-10" />
                 </div>
                 <p className="text-zinc-500 font-medium tracking-wide text-sm">Interactive Production Environment</p>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Infinite Marquee - Trusted By */}
      <section className="py-12 border-y border-white/[0.03] bg-[#050505] overflow-hidden relative">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-[#050505] to-transparent z-10"></div>
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-[#050505] to-transparent z-10"></div>
        
        <p className="text-center text-[10px] font-bold tracking-[0.2em] text-zinc-600 uppercase mb-8">Trusted by global creative teams</p>
        
        <div className="flex w-full overflow-hidden">
          <div className="flex min-w-full shrink-0 animate-marquee items-center justify-around gap-16 px-8">
            {["DLIGHT MEDIA", "VOGUE STUDIO", "OGILVY", "BBDO", "PENTAGRAM", "W+K", "MEDIA MONKS"].map((brand, i) => (
              <span key={i} className="font-display font-bold text-2xl text-zinc-500/50 whitespace-nowrap hover:text-zinc-300 transition-colors duration-300 cursor-default">
                {brand}
              </span>
            ))}
          </div>
          <div className="flex min-w-full shrink-0 animate-marquee items-center justify-around gap-16 px-8" aria-hidden="true">
            {["DLIGHT MEDIA", "VOGUE STUDIO", "OGILVY", "BBDO", "PENTAGRAM", "W+K", "MEDIA MONKS"].map((brand, i) => (
              <span key={i} className="font-display font-bold text-2xl text-zinc-500/50 whitespace-nowrap hover:text-zinc-300 transition-colors duration-300 cursor-default">
                {brand}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Modules/Features Section */}
      <section id="features" className="py-32 px-6 relative bg-dark-bg">
        <div className="max-w-7xl mx-auto">
          <div className="mb-20 text-center md:text-left md:w-2/3">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6 tracking-tight">Four pillars of <br/><span className="text-zinc-500">creative generation.</span></h2>
            <p className="text-xl text-zinc-400 font-light leading-relaxed">
              ACD OS is a specialized operating system with core modules engineered to output production-ready creative directions, not just chat.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
            {[
              {
                icon: ImageIcon,
                title: "Image Direction",
                desc: "Generate highly technical image prompts. Includes specific camera settings (ISO, Shutter), lighting setups (Rembrandt, Rim), and lens focal lengths."
              },
              {
                icon: Video,
                title: "Video Direction",
                desc: "Plan shot-by-shot video sequences. Output includes camera movement directions (pan, tilt, dolly), frame rates, and visual mood boards."
              },
              {
                icon: Wand2,
                title: "Retouching Guides",
                desc: "Create precise, non-destructive retouching instructions. Generate step-by-step guides for color grading, frequency separation, and dodging/burning."
              },
              {
                icon: LayoutPanelTop,
                title: "Campaign Builder",
                desc: "Orchestrate massive multi-platform campaigns. Maintain brand consistency across Instagram reels, billboards, and print ads with a unified visual language."
              }
            ].map((module, idx) => (
              <div key={idx} className="group relative rounded-[2rem] border border-white/[0.05] bg-[#0A0A0A] p-10 hover:bg-[#111111] transition-all duration-500 overflow-hidden">
                {/* Hover Glow */}
                <div className="absolute -inset-px rounded-[2rem] opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-brand-500/10 via-transparent to-transparent pointer-events-none" />
                
                <div className="relative z-10 flex flex-col h-full justify-between">
                  <div>
                    <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-center text-zinc-300 mb-8 group-hover:scale-110 group-hover:bg-brand-500/10 group-hover:text-brand-400 group-hover:border-brand-500/20 transition-all duration-500 ease-out">
                      <module.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-2xl font-semibold mb-4 text-white tracking-tight">{module.title}</h3>
                    <p className="text-zinc-400 font-light leading-relaxed text-lg">{module.desc}</p>
                  </div>
                  
                  <div className="mt-8 flex items-center text-sm font-medium text-zinc-500 group-hover:text-white transition-colors duration-300">
                    Explore Module <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform duration-300" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Workflow Section with Premium Cards */}
      <section id="workflow" className="py-32 px-6 bg-[#050505] border-t border-white/[0.03]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 tracking-tight">Seamless Workflow</h2>
            <p className="text-xl text-zinc-400 font-light">From blank canvas to production-ready assets in minutes.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 relative">
            {[
              {
                step: "01",
                title: "Initialize Project",
                desc: "Set up a workspace. Define base instructions, brand guidelines, and constraints that the AI will strictly follow.",
                color: "from-blue-500/20 to-transparent"
              },
              {
                step: "02",
                title: "Iterative Chat",
                desc: "Talk to the Creative Engine. Describe your rough idea, and the AI will expand it into a detailed visual concept.",
                color: "from-brand-500/20 to-transparent"
              },
              {
                step: "03",
                title: "Export JSON",
                desc: "Copy the structured output containing camera settings, lighting, and negative prompts directly to your team.",
                color: "from-purple-500/20 to-transparent"
              }
            ].map((item, i) => (
              <div key={i} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-700 rounded-3xl blur-xl -z-10" />
                <div className="h-full rounded-3xl border border-white/[0.05] bg-[#0A0A0A] p-8 hover:-translate-y-2 transition-all duration-500 ease-out">
                  <div className="text-5xl font-display font-bold text-white/[0.05] group-hover:text-brand-500/20 transition-colors duration-500 mb-6">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-semibold mb-4 text-white">{item.title}</h3>
                  <p className="text-zinc-400 font-light leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Scenario Section - Interactive Feel */}
      <section id="demo" className="py-32 px-6 bg-dark-bg border-t border-white/[0.03]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.03] border border-white/[0.08] text-xs tracking-wider font-medium text-zinc-300 mb-8 uppercase">
              <Layers className="w-3.5 h-3.5 text-brand-400" /> Case Study
            </div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-8 tracking-tight">Summer Fashion <br/><span className="text-zinc-500">Campaign.</span></h2>
            <p className="text-lg text-zinc-400 font-light leading-relaxed mb-10">
              Imagine pitching a luxury summer wear brand. Instead of hours on mood boards, you initialize ACD OS. Within minutes, you have a complete technical brief.
            </p>
            <div className="space-y-6 mb-12">
              {[
                "Input: 'Summer campaign on a yacht, luxury feel, warm tones.'",
                "OS generates 3 visual directions with mood descriptions.",
                "Outputs precise Midjourney prompts: '35mm lens, golden hour, Kodak Portra 400'.",
                "Export structured JSON brief directly to production."
              ].map((text, i) => (
                <div key={i} className="flex items-start gap-4 group">
                  <div className="w-6 h-6 rounded-full bg-white/[0.03] border border-white/[0.1] flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-brand-500 group-hover:border-brand-500 transition-colors duration-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-zinc-500 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <span className="text-zinc-300 font-light leading-relaxed group-hover:text-white transition-colors duration-300">{text}</span>
                </div>
              ))}
            </div>
            <Link
              href="/chat"
              className="inline-flex items-center gap-2 text-brand-400 font-medium hover:text-brand-300 transition-colors group text-lg"
            >
              Try it yourself <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          
          <div className="lg:w-1/2 w-full">
            {/* Highly Premium Mockup Card */}
            <div className="rounded-3xl bg-[#0A0A0A] border border-white/[0.08] p-8 shadow-2xl relative overflow-hidden group hover:border-white/[0.15] transition-colors duration-500">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-600 via-brand-400 to-transparent opacity-50"></div>
              
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-brand-600 flex items-center justify-center shadow-lg shadow-brand-500/20">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-base font-semibold text-white tracking-tight">Creative Engine</p>
                  <p className="text-sm text-brand-300/70 font-mono">Output Generated_</p>
                </div>
              </div>
              
              <div className="space-y-5 bg-black/50 rounded-2xl p-6 border border-white/[0.03]">
                <div className="flex gap-2 mb-2">
                  <span className="px-2.5 py-1 text-[11px] font-mono rounded bg-brand-500/10 text-brand-300 border border-brand-500/20">JSON</span>
                  <span className="px-2.5 py-1 text-[11px] font-mono rounded bg-white/[0.05] text-zinc-400 border border-white/[0.05]">200 OK</span>
                </div>
                <div className="font-mono text-sm text-zinc-400 leading-loose">
                  <span className="text-brand-300">"camera_settings"</span>: {"{"}<br/>
                  &nbsp;&nbsp;<span className="text-emerald-300">"lens"</span>: <span className="text-amber-200">"35mm prime"</span>,<br/>
                  &nbsp;&nbsp;<span className="text-emerald-300">"lighting"</span>: <span className="text-amber-200">"Golden hour, harsh shadows"</span>,<br/>
                  &nbsp;&nbsp;<span className="text-emerald-300">"film_stock"</span>: <span className="text-amber-200">"Kodak Portra 400"</span><br/>
                  {"}"},<br/>
                  <span className="text-brand-300">"prompt"</span>: <span className="text-amber-200">"High fashion editorial..."</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/[0.05] py-20 px-6 bg-[#030303]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
             <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center text-black">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="font-display font-semibold text-xl tracking-tight text-white">ACD OS</span>
            </div>
            <p className="text-zinc-500 max-w-sm font-light leading-relaxed">The operating system for modern creative directors and visual storytellers. Professional grade. Zero compromises.</p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-6 tracking-tight">Product</h4>
            <ul className="space-y-4 text-sm text-zinc-500 font-light">
              <li><a href="#" className="hover:text-white transition-colors duration-300">Features</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Pricing</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Changelog</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Documentation</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-6 tracking-tight">Company</h4>
            <ul className="space-y-4 text-sm text-zinc-500 font-light">
              <li><a href="#" className="hover:text-white transition-colors duration-300">About</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Blog</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors duration-300">Contact</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 pt-8 border-t border-white/[0.05]">
          <p className="text-zinc-600 text-sm font-light">© {new Date().getFullYear()} AI Creative Direction OS. All rights reserved.</p>
          <div className="flex gap-8 text-sm text-zinc-600 font-light">
            <a href="#" className="hover:text-zinc-300 transition-colors duration-300">Privacy Policy</a>
            <a href="#" className="hover:text-zinc-300 transition-colors duration-300">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
