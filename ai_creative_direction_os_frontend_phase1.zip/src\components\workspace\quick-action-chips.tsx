"use client";

import { Clapperboard, Image, Megaphone, PenTool, Sparkles, Wand2 } from "lucide-react";

type QuickActionChipsProps = {
  onSelect: (value: string) => void;
};

const chips = [
  { label: "Image Prompt", icon: Image, value: "Create an image prompt for " },
  { label: "Product Ad", icon: Megaphone, value: "Create a product advertising prompt for " },
  { label: "Key Visual", icon: Sparkles, value: "Create a key visual direction for " },
  { label: "Retouching", icon: Wand2, value: "Create retouching direction for " },
  { label: "Campaign", icon: PenTool, value: "Plan a campaign visual direction for " },
  { label: "Video", icon: Clapperboard, value: "Create a video prompt for " }
];

export function QuickActionChips({ onSelect }: QuickActionChipsProps) {
  return (
    <div className="flex max-w-4xl flex-wrap justify-center gap-3">
      {chips.map((chip) => {
        const Icon = chip.icon;
        return (
          <button
            key={chip.label}
            type="button"
            className="inline-flex h-10 items-center gap-2.5 rounded-full border border-white/[0.08] bg-white/[0.02] px-5 text-[14px] font-medium text-zinc-300 transition-all hover:border-brand-500/50 hover:bg-brand-500/10 hover:text-white hover:shadow-sm hover:-translate-y-0.5 backdrop-blur-sm"
            onClick={() => onSelect(chip.value)}
          >
            <Icon className="h-4 w-4 text-brand-400/80" aria-hidden="true" />
            {chip.label}
          </button>
        );
      })}
    </div>
  );
}
