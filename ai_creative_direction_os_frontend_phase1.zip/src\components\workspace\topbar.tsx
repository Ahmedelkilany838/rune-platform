"use client";

import { Menu, Sparkles, Plus } from "lucide-react";
import type { ConnectionStatus } from "@/lib/chat-types";
import { Button } from "@/components/ui/button";

type TopbarProps = {
  connectionStatus: ConnectionStatus;
  onNewPrompt: () => void;
  activeProjectName?: string;
};

export function Topbar({ connectionStatus, onNewPrompt, activeProjectName }: TopbarProps) {
  return (
    <header className="flex h-16 items-center justify-between gap-4 glass-panel border-x-0 border-t-0 px-4 sm:px-6 z-20 sticky top-0">
      <div className="flex items-center gap-3 lg:hidden">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white shadow-lg">
          <Sparkles className="h-4 w-4" aria-hidden="true" />
        </div>
        <span className="text-base font-semibold font-display text-white">ACD OS</span>
      </div>
      
      <div className="hidden lg:flex items-center gap-2">
        {activeProjectName && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-brand-500/20 bg-brand-500/5 text-xs font-medium text-brand-300 mr-2">
            {activeProjectName}
          </div>
        )}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/[0.05] bg-dark-surface-elevated text-xs font-medium text-zinc-400">
          <span className={`w-2 h-2 rounded-full ${connectionStatus === 'connected' ? 'bg-emerald-500' : connectionStatus === 'error' ? 'bg-rose-500' : 'bg-brand-500 animate-pulse'}`} />
          {connectionStatus === 'connected' ? 'Engine Online' : connectionStatus === 'error' ? 'Connection Error' : 'Ready'}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="ghost"
          className="lg:hidden text-zinc-300 hover:text-white hover:bg-white/[0.05]"
          icon={<Menu className="h-5 w-5" aria-hidden="true" />}
          onClick={onNewPrompt}
          aria-label="Start a new prompt"
        >
          New
        </Button>
        <button
          className="hidden lg:flex h-9 items-center justify-center gap-2 px-4 rounded-full bg-white text-black text-sm font-medium hover:bg-zinc-200 transition-colors"
          onClick={onNewPrompt}
        >
          <Plus className="w-4 h-4" />
          New Chat
        </button>
      </div>
    </header>
  );
}
