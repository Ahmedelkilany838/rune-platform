# AI Creative Direction OS Frontend

Professional Next.js frontend for AI Creative Direction OS, a Creative Prompt Direction System connected to an existing n8n and Supabase backend pipeline.

This Phase 1 app is the user-facing chat and output inspection surface for:

- WF-00A Chat Intake Skeleton
- SW-00A Input Normalizer Agent
- SW-00B Intent Router Agent
- SW-00C Brief Decision Extractor Agent
- SW-00D Response Composer Agent
- WF-01 Prompt Request Creator
- WF-10 Prompt Generation Engine

The browser never calls n8n directly. It calls the local server route, which proxies to WF-00A securely.

## Tech Stack

- Next.js App Router
- TypeScript
- Tailwind CSS
- React components
- Server-side API route proxy
- Vitest for isolated normalization and API route tests

## Install

```bash
npm install
```

## Environment Variables

Create a local `.env.local` file for development:

```bash
N8N_CHAT_INTAKE_WEBHOOK_URL=your-wf-00a-webhook-url
NEXT_PUBLIC_APP_NAME=AI Creative Direction OS
```

Do not commit `.env.local`. The committed `.env.example` intentionally contains no real webhook value.

Optional future variables are present in `.env.example` but are not required for Phase 1:

```bash
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
```

## Run Locally

```bash
npm run dev
```

Open the local URL printed by Next.js, usually:

```text
http://localhost:3000
```

## Connect n8n Webhook

Set `N8N_CHAT_INTAKE_WEBHOOK_URL` in `.env.local` to the production or test WF-00A Chat Intake Skeleton webhook URL.

The frontend sends this payload server-side:

```json
{
  "workspace_id": "22222222-2222-4222-8222-222222222222",
  "user_id": "11111111-1111-4111-8111-111111111111",
  "project_id": null,
  "conversation_session_id": null,
  "message_text": "user brief",
  "channel": "frontend_chat",
  "attachments": [],
  "metadata": {
    "source": "ai_creative_direction_os_frontend",
    "ui_version": "phase_1_chat"
  }
}
```

## Test With a Simple Prompt

After configuring `.env.local`, run the app and submit:

```text
Create a premium product advertising prompt for a black luxury perfume bottle on wet obsidian stone, cinematic lighting, Instagram hero visual.
```

The UI should show the assistant response, generated prompt card when WF-10 returns one, and the normalized pipeline metadata in the Output Inspector.

## Verification

Run isolated tests:

```bash
npm test
```

Build the app:

```bash
npm run build
```

The test suite covers:

- Empty message returns 400
- Over-limit message returns 400
- Missing webhook env returns 500 without exposing the URL
- Valid message calls n8n server-side through a mocked isolated fetch
- WF-00A merged response normalization
- WF-10 direct object normalization
- WF-10 direct array normalization
- Error-only response normalization
- JSON-string `structured_output` parsing
- JSON-string `used_knowledge_blocks` parsing

## Known Limitations

- Auth is not implemented yet.
- File/reference upload is UI placeholder only.
- Product locking UI is not implemented yet.
- Character locking UI is not implemented yet.
- Campaign builder UI is not implemented yet.
- WF-11 validation/repair is referenced but not implemented yet.
- Current generated prompt is `layer_1_draft`.
- `workspace_id` and `user_id` are development config values in `src/lib/app-config.ts`.
- Supabase is not connected from the frontend in Phase 1.

## Next Recommended Phase

Add authenticated workspace/session ownership, then introduce reference upload and analysis as a dedicated flow that feeds the existing backend without exposing Supabase service role keys or n8n webhook URLs to the browser.
